package kindergarten;

public class Main {
    public static void main(String[] args) {
        softUniKindergarten kindergarten = new softUniKindergarten("Sunshine", 8);
        Child childOne = new Child("Lilyana", "Petrova", 3, "Selena", "0899");
        Child childTwo = new Child("Elona", "Muskova", 4,"Max", "0888");
        Child childThree = new Child("George", "Bush", 5,"Ivan", "0988");
        Child childFour = new Child("Ruzha", "Ignatova", 6,"George", "0789");
        Child childFive = new Child("Veselina", "Kostadinova", 3,"Nikolas", "0788");
        Child childSix = new Child("Tom", "Todorov", 2,"Zendaya", "0799");
        Child childSeven = new Child("Sara", "Gomez", 2,"Victor", "0998");
        Child childEight = new Child("Greta", "Thunberg", 3,"Boris", "0999");
        Child childNine = new Child("Anna", "Cameron", 4, "Breja", "0999");
        System.out.println(kindergarten.addChild(childOne)); // true
        System.out.println(kindergarten.addChild(childTwo)); // true
        System.out.println(kindergarten.addChild(childThree)); // true
        System.out.println(kindergarten.addChild(childFour)); // true
        System.out.println(kindergarten.addChild(childFive)); // true
        System.out.println(kindergarten.addChild(childSix)); // true
        System.out.println(kindergarten.addChild(childSeven)); // true
    }
}
